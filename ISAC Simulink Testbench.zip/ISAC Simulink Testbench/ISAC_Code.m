% Jai Mangal
% PhD22104
% IIIT Delhi (ISAC Master Code)

%% Initialization and Setup
clc;            % Clear command window
clear;          % Remove all variables from the workspace
close all;      % Close all open figure windows

tic             % Start timer for performance measurement

%% RF Impairments
% Define the range of path loss values for radar and communication systems
PATH_LOSS_RAD = 145:5:170;   % Radar path loss values (in dB)
PATH_LOSS_COMM = 115:5:145;  % Communication path loss values (in dB)

% Set RF impairment parameters (these may be tuned as needed)
IQ_GAIN = 0;                % IQ gain imbalance (in dB)
IQ_PHASE = 0;               % IQ phase imbalance (in degrees)
LO_RF = inf;                % Local oscillator RF leakage (in dB or 'inf' for ideal)
PHASE_NOISE_FREQ = 1;       % Phase noise frequency (in Hz or appropriate units)
PHASE_NOISE = -inf;         % Phase noise level (in dB or '-inf' for ideal)
PHASE_OFFSET = 0;           % Constant phase offset (in degrees)
FREQ_OFFSET = 0;            % Frequency offset (in Hz)

%% Radar Parameters
% Load Golay sequences used for radar waveform processing
load('golay_bit.mat');                  
load('golay_seq.mat');  

% Define radar sampling parameters
tsamp = 1/2.64e9;           % Sampling time based on a 2.64 GHz sampling rate
c = 3e8;                    % Speed of light (m/s)

% Define radar target parameters
ang = 20;                   % Target angle (in degrees)
range = 30;                 % Target range (in meters)

% Calculate the number of samples corresponding to the round-trip delay
samp = (2*range)/(c*tsamp);

%% Communication Metrics Initialization
% Initialize matrices to store performance metrics for each combination of path losses
ber = zeros(length(PATH_LOSS_RAD), length(PATH_LOSS_COMM));       % Bit Error Rate (BER)
ber_sym = zeros(length(PATH_LOSS_RAD), length(PATH_LOSS_COMM));   % Symbol Error Rate (BER for symbols)
rms_per = zeros(length(PATH_LOSS_RAD), length(PATH_LOSS_COMM));     % Root Mean Square Error (in dB)
max_per = zeros(length(PATH_LOSS_RAD), length(PATH_LOSS_COMM));     % Maximum Error (in dB)

%% Simulation Loop for Radar and Communication
% Loop over each radar path loss value
for i = 1:length(PATH_LOSS_RAD)
    % Set RF impairment parameters (re-initialized for each outer loop iteration)
    iq_gain = IQ_GAIN;
    iq_phase = IQ_PHASE;
    lo_rf = LO_RF;
    phase_noise_freq = PHASE_NOISE_FREQ;
    phase_noise = PHASE_NOISE;
    phase_offset = PHASE_OFFSET;
    freq_offset = FREQ_OFFSET;
    
    % Loop over each communication path loss value
    for j = 1:length(PATH_LOSS_COMM)
        % Assign current path loss values for radar and communication
        path_loss_rad = PATH_LOSS_RAD(i);
        path_loss_comm = PATH_LOSS_COMM(j);
        
        % Display the current simulation parameters
        displ = ['Radar Path Loss = ', num2str(path_loss_rad), '  ,   ' ...
            'Comm Path Loss = ', num2str(path_loss_comm)];
        disp(displ)
        
        % Run the Simulink model for radar simulation
        out_radar = sim("Radar_Testbench");
        
        % Run the Simulink model for communication simulation
        out_comm = sim("Comm_Testbench");
        
        % Store the final BER and symbol error rate from simulation outputs
        ber(i,j) = ber_nu(end,1);            % BER from communication output
        ber_sym(i,j) = ber_nu_sym(end,1);      % Symbol error rate
        
        % Store the error vector magnitude (EVM) metrics from communication output
        rms_per(i,j) = out_comm.evm_db(end, 1);      % RMS EVM in dB
        max_per(i,j) = out_comm.evm_db_max(end, 1);    % Maximum EVM in dB
    end
end

toc     % Display elapsed time